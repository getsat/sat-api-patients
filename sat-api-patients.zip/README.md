# S.A.T - API Patients

API simple pour enregistrer et consulter des patients (projet Santé À Tous).